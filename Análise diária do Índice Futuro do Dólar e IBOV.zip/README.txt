ANÁLISE TÉCNICA - ÍNDICE FUTURO E DÓLAR FUTURO
Data de geração: 18/04/2025 18:09:01

CONTEÚDO DO RELATÓRIO:

1. VISÃO GERAL
   - analise_tecnica_completa.png: Relatório visual completo com todas as análises

2. ANÁLISES INDIVIDUAIS
   Índice Bovespa Futuro (INDFUT):
   - IBOVESPA_analise_diaria.png: Análise técnica do gráfico diário
   - IBOVESPA_analise_60min.png: Análise técnica do gráfico de 60 minutos
   - IBOVESPA_analise_consolidada.png: Análise consolidada dos dois timeframes
   - IBOVESPA_relatorio_tecnico.txt: Relatório técnico detalhado

   Dólar Futuro (WDOFUT):
   - DOLAR_analise_diaria.png: Análise técnica do gráfico diário
   - DOLAR_analise_60min.png: Análise técnica do gráfico de 60 minutos
   - DOLAR_analise_consolidada.png: Análise consolidada dos dois timeframes
   - DOLAR_relatorio_tecnico.txt: Relatório técnico detalhado

3. COMO UTILIZAR ESTE RELATÓRIO
   - As imagens contêm análises técnicas completas com suportes, resistências, Fibonacci e tendências
   - Os relatórios técnicos fornecem detalhes adicionais e recomendações
   - Recomenda-se analisar tanto o timeframe diário quanto o de 60 minutos para decisões
   - Esta análise deve ser atualizada diariamente para acompanhar a evolução do mercado

4. INDICADORES UTILIZADOS
   - Médias Móveis: MM8, MM20, MM50, MM200
   - Osciladores: RSI (Índice de Força Relativa), MACD
   - Suportes e Resistências: Identificados por máximos e mínimos locais
   - Fibonacci: Retrações e projeções calculadas a partir de pivôs significativos

5. OBSERVAÇÕES IMPORTANTES
   - Esta análise é baseada exclusivamente em indicadores técnicos
   - Recomenda-se complementar com análise fundamentalista e de sentimento de mercado
   - Passado não é garantia de resultados futuros
   - Utilize esta análise como uma ferramenta de apoio à decisão, não como recomendação definitiva
