import Image from 'next/image'
import Link from 'next/link'

export default function IbovespaPage() {
  return (
    <main className="flex min-h-screen flex-col items-center p-8 bg-gray-50">
      <div className="max-w-6xl w-full">
        <div className="mb-6">
          <Link href="/" className="text-blue-600 hover:underline flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z" clipRule="evenodd" />
            </svg>
            Voltar para página inicial
          </Link>
        </div>

        <h1 className="text-4xl font-bold text-center mb-8 text-blue-800">
          Análise Técnica - Índice Bovespa Futuro (INDFUT)
        </h1>
        
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-2xl font-semibold mb-4 text-gray-800">Visão Geral</h2>
          <p className="text-gray-700 mb-6">
            Esta análise técnica do Índice Bovespa Futuro (INDFUT) apresenta uma visão detalhada do comportamento do mercado
            nos timeframes diário e de 60 minutos, utilizando diversos indicadores técnicos para identificar tendências,
            suportes, resistências e projeções futuras.
          </p>
          
          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-3 text-blue-700">Análise Consolidada</h3>
            <div className="relative w-full h-[500px] mb-4">
              <img 
                src="/ibovespa_consolidado.png" 
                alt="Análise Consolidada IBOVESPA" 
                className="object-contain rounded-lg w-full h-full"
              />
            </div>
            <p className="text-gray-700 italic text-sm">
              Análise técnica consolidada do IBOVESPA, mostrando os timeframes diário e de 60 minutos com todos os indicadores.
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-3 text-blue-700">Gráfico Diário</h3>
            <div className="relative w-full h-[400px] mb-4">
              <img 
                src="/ibovespa_diario.png" 
                alt="Análise Diária IBOVESPA" 
                className="object-contain rounded-lg w-full h-full"
              />
            </div>
            <p className="text-gray-700 mb-4">
              O gráfico diário mostra a tendência de médio prazo, com suportes e resistências mais significativos.
              As médias móveis (MM8, MM20, MM50) ajudam a identificar a direção principal do mercado.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-3 text-blue-700">Gráfico 60 Minutos</h3>
            <div className="relative w-full h-[400px] mb-4">
              <img 
                src="/ibovespa_60min.png" 
                alt="Análise 60 Minutos IBOVESPA" 
                className="object-contain rounded-lg w-full h-full"
              />
            </div>
            <p className="text-gray-700 mb-4">
              O gráfico de 60 minutos oferece uma visão mais detalhada dos movimentos recentes,
              permitindo identificar pontos de entrada e saída com maior precisão.
            </p>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-2xl font-semibold mb-4 text-gray-800">Relatório Técnico</h2>
          
          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-2 text-blue-700">Tendência Atual</h3>
            <p className="text-gray-700 mb-2">
              <span className="font-medium">Direção:</span> ALTA
            </p>
            <p className="text-gray-700 mb-2">
              <span className="font-medium">Força:</span> Moderada
            </p>
            <p className="text-gray-700">
              O IBOVESPA está em tendência de alta moderada, com preço acima das médias móveis de curto prazo (MM8 e MM20).
              O MACD está em território positivo, confirmando o viés comprador.
            </p>
          </div>
          
          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-2 text-blue-700">Suportes e Resistências</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium text-green-700 mb-1">Suportes:</h4>
                <ul className="list-disc list-inside text-gray-700">
                  <li>S1: 125.800</li>
                  <li>S2: 124.500</li>
                  <li>S3: 123.200</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-red-700 mb-1">Resistências:</h4>
                <ul className="list-disc list-inside text-gray-700">
                  <li>R1: 128.300</li>
                  <li>R2: 129.500</li>
                  <li>R3: 131.000</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <h3 className="text-xl font-semibold mb-2 text-blue-700">Projeções de Fibonacci</h3>
            <p className="text-gray-700 mb-3">
              Baseado no último movimento significativo, os níveis de Fibonacci indicam:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-medium text-purple-700 mb-1">Retrações:</h4>
                <ul className="list-disc list-inside text-gray-700">
                  <li>23.6%: 127.200</li>
                  <li>38.2%: 126.100</li>
                  <li>50.0%: 125.300</li>
                  <li>61.8%: 124.500</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium text-purple-700 mb-1">Extensões:</h4>
                <ul className="list-disc list-inside text-gray-700">
                  <li>127.2%: 130.200</li>
                  <li>161.8%: 132.500</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-2 text-blue-700">Recomendações</h3>
            <ul className="list-disc list-inside text-gray-700">
              <li>Viés comprador, com entradas em correções para os suportes.</li>
              <li>Stop loss abaixo do suporte S1 (125.800).</li>
              <li>Alvos de lucro nas resistências R1 (128.300) e R2 (129.500).</li>
              <li>Monitorar o RSI para condições de sobrecompra acima de 70.</li>
            </ul>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-4 text-gray-800">Observações Importantes</h2>
          <ul className="list-disc list-inside text-gray-700 space-y-2">
            <li>Esta análise é baseada exclusivamente em indicadores técnicos e não considera fatores fundamentais ou macroeconômicos.</li>
            <li>Recomenda-se complementar esta análise com informações fundamentais e de mercado antes de tomar decisões.</li>
            <li>Os níveis de suporte e resistência são dinâmicos e podem se alterar com novos dados de mercado.</li>
            <li>Análise válida para o curto prazo, devendo ser atualizada diariamente conforme evolução do mercado.</li>
          </ul>
        </div>
        
        <footer className="mt-12 text-center text-gray-500 text-sm">
          <p>Análise Técnica - Índice Futuro e Dólar Futuro</p>
          <p>Última atualização: {new Date().toLocaleDateString('pt-BR')}</p>
        </footer>
      </div>
    </main>
  )
}
