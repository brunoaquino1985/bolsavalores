import pandas as pd
import numpy as np
import os
from datetime import datetime

# Diretórios para dados e resultados
dados_dir = 'dados'
resultados_dir = 'resultados'
os.makedirs(resultados_dir, exist_ok=True)

print("Iniciando reestruturação dos dados brutos...")

# Função para reestruturar os dados brutos
def reestruturar_dados(arquivo, nome_dataset):
    print(f"\nReestruturando {nome_dataset}...")
    
    # Ler o arquivo CSV pulando as três primeiras linhas (cabeçalhos problemáticos)
    df = pd.read_csv(f'{dados_dir}/{arquivo}', skiprows=3)
    
    # Verificar as primeiras linhas para diagnóstico
    print(f"Primeiras linhas após remoção de cabeçalhos:")
    print(df.head(2))
    
    # Definir a primeira coluna como índice e converter para datetime
    df.set_index(df.columns[0], inplace=True)
    df.index = pd.to_datetime(df.index)
    df.index.name = 'Date'
    
    # Verificar resultado após reestruturação
    print(f"Formato dos dados: {df.shape}")
    print(f"Período: {df.index[0]} a {df.index[-1]}")
    
    # Salvar dados reestruturados
    df.to_csv(f'{resultados_dir}/{arquivo.replace(".csv", "_reestruturado.csv")}')
    
    return df

# Reestruturar cada conjunto de dados
ibovespa_diario = reestruturar_dados('ibovespa_diario.csv', 'IBOVESPA Diário')
dolar_diario = reestruturar_dados('dolar_diario.csv', 'Dólar Diário')
ibovespa_60min = reestruturar_dados('ibovespa_60min.csv', 'IBOVESPA 60min')
dolar_60min = reestruturar_dados('dolar_60min.csv', 'Dólar 60min')

print("\nResumo final após reestruturação:")
print(f"IBOVESPA Diário: {len(ibovespa_diario)} registros, período de {ibovespa_diario.index[0]} a {ibovespa_diario.index[-1]}")
print(f"Dólar Diário: {len(dolar_diario)} registros, período de {dolar_diario.index[0]} a {dolar_diario.index[-1]}")
print(f"IBOVESPA 60min: {len(ibovespa_60min)} registros, período de {ibovespa_60min.index[0]} a {ibovespa_60min.index[-1]}")
print(f"Dólar 60min: {len(dolar_60min)} registros, período de {dolar_60min.index[0]} a {dolar_60min.index[-1]}")

print("\nDados reestruturados com sucesso!")
