import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import os
from datetime import datetime
import shutil

# Diretórios para dados e resultados
resultados_dir = 'resultados'
analise_dir = os.path.join(resultados_dir, 'analise_consolidada')
os.makedirs(analise_dir, exist_ok=True)

print("Iniciando geração da análise técnica consolidada...")

# Função para criar relatório consolidado
def gerar_relatorio_consolidado(ativo, nome_completo):
    """
    Gera um relatório consolidado combinando análises de diferentes timeframes
    """
    print(f"\nGerando relatório consolidado para {nome_completo}...")
    
    # Criar figura para o relatório consolidado
    fig = plt.figure(figsize=(20, 24))
    
    # Adicionar título principal
    fig.suptitle(f'Análise Técnica Consolidada - {nome_completo}', fontsize=20, y=0.98)
    
    # Adicionar data da análise
    plt.figtext(0.5, 0.96, f'Data da análise: {datetime.now().strftime("%d/%m/%Y")}', 
                ha='center', fontsize=12)
    
    # Copiar as imagens de análise para o relatório
    img_diario = plt.imread(f'{resultados_dir}/analise_diaria/{ativo}_analise_diaria.png')
    img_60min = plt.imread(f'{resultados_dir}/analise_60min/{ativo}_analise_60min.png')
    
    # Adicionar imagem da análise diária
    ax1 = fig.add_subplot(2, 1, 1)
    ax1.imshow(img_diario)
    ax1.axis('off')
    ax1.set_title('Análise Diária', fontsize=16, pad=20)
    
    # Adicionar imagem da análise de 60 minutos
    ax2 = fig.add_subplot(2, 1, 2)
    ax2.imshow(img_60min)
    ax2.axis('off')
    ax2.set_title('Análise 60 Minutos', fontsize=16, pad=20)
    
    # Ajustar layout
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    
    # Salvar figura
    plt.savefig(f'{analise_dir}/{ativo}_analise_consolidada.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Relatório consolidado salvo em {analise_dir}/{ativo}_analise_consolidada.png")
    
    # Copiar as imagens individuais para o diretório de análise consolidada
    shutil.copy(f'{resultados_dir}/analise_diaria/{ativo}_analise_diaria.png', 
                f'{analise_dir}/{ativo}_analise_diaria.png')
    shutil.copy(f'{resultados_dir}/analise_60min/{ativo}_analise_60min.png', 
                f'{analise_dir}/{ativo}_analise_60min.png')
    
    # Gerar relatório textual
    with open(f'{analise_dir}/{ativo}_relatorio_tecnico.txt', 'w') as f:
        f.write(f"RELATÓRIO DE ANÁLISE TÉCNICA - {nome_completo}\n")
        f.write(f"Data de geração: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
        
        # Carregar dados processados para extrair informações atuais
        df_diario = pd.read_csv(f'{resultados_dir}/{ativo.lower()}_diario_processado.csv', index_col=0, parse_dates=True)
        df_60min = pd.read_csv(f'{resultados_dir}/{ativo.lower()}_60min_processado.csv', index_col=0, parse_dates=True)
        
        # Informações gerais
        f.write("1. INFORMAÇÕES GERAIS\n")
        f.write(f"Preço atual: {df_diario['Close'].iloc[-1]:.2f}\n")
        f.write(f"Variação diária: {(df_diario['Close'].iloc[-1] - df_diario['Close'].iloc[-2]) / df_diario['Close'].iloc[-2] * 100:.2f}%\n")
        f.write(f"Volume médio (últimos 20 dias): {df_diario['Volume'].iloc[-20:].mean():.0f}\n\n")
        
        # Análise de tendência
        f.write("2. ANÁLISE DE TENDÊNCIA\n")
        
        # Verificar posição do preço em relação às médias móveis
        preco = df_diario['Close'].iloc[-1]
        mm8 = df_diario['MM8'].iloc[-1] if not pd.isna(df_diario['MM8'].iloc[-1]) else None
        mm20 = df_diario['MM20'].iloc[-1] if not pd.isna(df_diario['MM20'].iloc[-1]) else None
        mm50 = df_diario['MM50'].iloc[-1] if not pd.isna(df_diario['MM50'].iloc[-1]) else None
        
        f.write("Posição em relação às médias móveis (diário):\n")
        if mm8 is not None:
            f.write(f"- MM8: {'Acima' if preco > mm8 else 'Abaixo'} (Preço: {preco:.2f}, MM8: {mm8:.2f})\n")
        if mm20 is not None:
            f.write(f"- MM20: {'Acima' if preco > mm20 else 'Abaixo'} (Preço: {preco:.2f}, MM20: {mm20:.2f})\n")
        if mm50 is not None:
            f.write(f"- MM50: {'Acima' if preco > mm50 else 'Abaixo'} (Preço: {preco:.2f}, MM50: {mm50:.2f})\n")
        
        # Verificar inclinação das médias móveis
        mm20_5d_atras = None
        if mm20 is not None and len(df_diario) > 5:
            mm20_5d_atras = df_diario['MM20'].iloc[-6] if not pd.isna(df_diario['MM20'].iloc[-6]) else None
            if mm20_5d_atras is not None:
                inclinacao = "ascendente" if mm20 > mm20_5d_atras else "descendente"
                f.write(f"Inclinação da MM20: {inclinacao}\n")
        
        # Verificar RSI
        rsi = df_diario['RSI'].iloc[-1] if not pd.isna(df_diario['RSI'].iloc[-1]) else None
        if rsi is not None:
            condicao_rsi = "sobrecompra" if rsi > 70 else "sobrevenda" if rsi < 30 else "neutro"
            f.write(f"RSI atual: {rsi:.2f} ({condicao_rsi})\n")
        
        # Verificar MACD
        macd = df_diario['MACD'].iloc[-1] if not pd.isna(df_diario['MACD'].iloc[-1]) else None
        macd_signal = df_diario['MACD_Signal'].iloc[-1] if not pd.isna(df_diario['MACD_Signal'].iloc[-1]) else None
        if macd is not None and macd_signal is not None:
            sinal_macd = "compra" if macd > macd_signal else "venda"
            f.write(f"MACD: {sinal_macd.upper()} (MACD: {macd:.4f}, Sinal: {macd_signal:.4f})\n\n")
        
        # Suportes e resistências
        f.write("3. SUPORTES E RESISTÊNCIAS\n")
        
        # Identificar suportes e resistências manualmente a partir dos dados
        # Ordenar preços para identificar clusters
        closes = df_diario['Close'].tolist()
        closes.sort()
        
        # Identificar clusters de preços (suportes e resistências potenciais)
        clusters = []
        if len(closes) > 0:
            current_cluster = [closes[0]]
            threshold = closes[0] * 0.01  # 1% de tolerância
            
            for price in closes[1:]:
                if abs(price - current_cluster[-1]) <= threshold:
                    current_cluster.append(price)
                else:
                    if len(current_cluster) >= 3:  # Pelo menos 3 ocorrências para ser significativo
                        clusters.append(sum(current_cluster) / len(current_cluster))
                    current_cluster = [price]
            
            # Adicionar o último cluster se for significativo
            if len(current_cluster) >= 3:
                clusters.append(sum(current_cluster) / len(current_cluster))
        
        # Separar em suportes (abaixo do preço atual) e resistências (acima do preço atual)
        suportes = [c for c in clusters if c < preco]
        resistencias = [c for c in clusters if c > preco]
        
        # Limitar a 3 níveis mais próximos
        suportes = sorted(suportes, reverse=True)[:3] if suportes else []
        resistencias = sorted(resistencias)[:3] if resistencias else []
        
        f.write("Níveis de suporte (diário):\n")
        if suportes:
            for i, suporte in enumerate(suportes, 1):
                f.write(f"S{i}: {suporte:.2f}\n")
        else:
            f.write("Nenhum nível de suporte significativo identificado\n")
        
        f.write("\nNíveis de resistência (diário):\n")
        if resistencias:
            for i, resistencia in enumerate(resistencias, 1):
                f.write(f"R{i}: {resistencia:.2f}\n")
        else:
            f.write("Nenhum nível de resistência significativo identificado\n")
        
        f.write("\n4. PROJEÇÕES DE FIBONACCI\n")
        
        # Calcular níveis de Fibonacci para o último movimento significativo
        min_idx = df_diario['Low'].idxmin()
        df_apos_min = df_diario.loc[min_idx:]
        if len(df_apos_min) > 1:
            max_idx = df_apos_min['High'].idxmax()
            min_price = df_diario.loc[min_idx, 'Low']
            max_price = df_diario.loc[max_idx, 'High']
            
            # Calcular níveis de Fibonacci (retrações)
            range_price = max_price - min_price
            fib_23_6 = max_price - 0.236 * range_price
            fib_38_2 = max_price - 0.382 * range_price
            fib_50_0 = max_price - 0.5 * range_price
            fib_61_8 = max_price - 0.618 * range_price
            fib_78_6 = max_price - 0.786 * range_price
            
            # Calcular níveis de Fibonacci (extensões)
            fib_127_2 = max_price + 0.272 * range_price
            fib_161_8 = max_price + 0.618 * range_price
            
            f.write(f"Movimento de referência: Mínimo de {min_price:.2f} em {min_idx.strftime('%d/%m/%Y')} até máximo de {max_price:.2f} em {max_idx.strftime('%d/%m/%Y')}\n\n")
            
            f.write("Níveis de retração de Fibonacci:\n")
            f.write(f"- 23.6%: {fib_23_6:.2f}\n")
            f.write(f"- 38.2%: {fib_38_2:.2f}\n")
            f.write(f"- 50.0%: {fib_50_0:.2f}\n")
            f.write(f"- 61.8%: {fib_61_8:.2f}\n")
            f.write(f"- 78.6%: {fib_78_6:.2f}\n\n")
            
            f.write("Níveis de extensão de Fibonacci:\n")
            f.write(f"- 127.2%: {fib_127_2:.2f}\n")
            f.write(f"- 161.8%: {fib_161_8:.2f}\n\n")
        else:
            f.write("Dados insuficientes para cálculo de níveis de Fibonacci\n\n")
        
        f.write("5. CONCLUSÃO E PERSPECTIVAS\n")
        
        # Determinar tendência com base nos indicadores
        tendencia = None
        forca = 0
        
        # Critérios para tendência
        if mm8 is not None and mm20 is not None:
            if preco > mm8 and preco > mm20:
                tendencia = "alta"
                forca += 2
            elif preco < mm8 and preco < mm20:
                tendencia = "baixa"
                forca += 2
            elif preco > mm20:
                tendencia = "alta"
                forca += 1
            elif preco < mm20:
                tendencia = "baixa"
                forca += 1
        
        # Verificar inclinação da MM20
        if mm20 is not None and mm20_5d_atras is not None:
            if mm20 > mm20_5d_atras and tendencia == "alta":
                forca += 1
            elif mm20 < mm20_5d_atras and tendencia == "baixa":
                forca += 1
            elif mm20 > mm20_5d_atras:
                tendencia = "alta"
                forca = 1
            elif mm20 < mm20_5d_atras:
                tendencia = "baixa"
                forca = 1
        
        # Verificar RSI
        if rsi is not None:
            if rsi > 70 and tendencia == "alta":
                forca -= 1  # Sobrecompra em tendência de alta = alerta
            elif rsi < 30 and tendencia == "baixa":
                forca -= 1  # Sobrevenda em tendência de baixa = alerta
        
        # Verificar MACD
        if macd is not None and macd_signal is not None:
            if macd > macd_signal and tendencia == "alta":
                forca += 1
            elif macd < macd_signal and tendencia == "baixa":
                forca += 1
            elif macd > macd_signal:
                tendencia = "alta"
                forca = 1
            elif macd < macd_signal:
                tendencia = "baixa"
                forca = 1
        
        # Determinar força da tendência
        forca_desc = "forte" if forca >= 3 else "moderada" if forca >= 1 else "fraca"
        
        f.write(f"Tendência atual: {tendencia.upper() if tendencia else 'INDEFINIDA'} ({forca_desc})\n\n")
        
        # Perspectivas
        f.write("Perspectivas de curto prazo:\n")
        
        # Criar strings de suportes e resistências para usar no texto
        suportes_str = ", ".join([f"{s:.2f}" for s in suportes]) if suportes else "não identificados"
        resistencias_str = ", ".join([f"{r:.2f}" for r in resistencias]) if resistencias else "não identificadas"
        
        if tendencia == "alta":
            if rsi is not None and rsi > 70:
                f.write("- Mercado em tendência de alta, mas com sinais de sobrecompra no RSI, sugerindo possível correção de curto prazo.\n")
                f.write(f"- Atenção aos suportes em {suportes_str} para possíveis entradas.\n")
                f.write(f"- Próximas resistências em {resistencias_str}.\n")
            else:
                f.write("- Mercado em tendência de alta com força técnica.\n")
                f.write(f"- Próximas resistências em {resistencias_str}.\n")
                f.write(f"- Suportes para correções em {suportes_str}.\n")
        elif tendencia == "baixa":
            if rsi is not None and rsi < 30:
                f.write("- Mercado em tendência de baixa, mas com sinais de sobrevenda no RSI, sugerindo possível repique técnico.\n")
                f.write(f"- Atenção às resistências em {resistencias_str} para possíveis saídas.\n")
                f.write(f"- Próximos suportes em {suportes_str}.\n")
            else:
                f.write("- Mercado em tendência de baixa com pressão vendedora.\n")
                f.write(f"- Próximos suportes em {suportes_str}.\n")
                f.write(f"- Resistências para repiques em {resistencias_str}.\n")
        else:
            f.write("- Mercado sem tendência definida, em fase de consolidação.\n")
            f.write(f"- Monitorar rompimento de suportes ({suportes_str}) ou resistências ({resistencias_str}).\n")
        
        f.write("\n6. RECOMENDAÇÕES\n")
        
        # Recomendações baseadas na análise
        if tendencia == "alta" and forca >= 2:
            f.write("- Viés comprador, com entradas em correções para os suportes.\n")
            if suportes:
                f.write(f"- Stop loss abaixo do suporte S1 ({suportes[0]:.2f}).\n")
            else:
                f.write("- Definir stop loss com base na volatilidade recente do mercado.\n")
                
            if resistencias:
                f.write(f"- Alvos de lucro nas resistências R1 ({resistencias[0]:.2f})")
                if len(resistencias) > 1:
                    f.write(f" e R2 ({resistencias[1]:.2f}).\n")
                else:
                    f.write(".\n")
            else:
                f.write("- Definir alvos de lucro com base em projeções de Fibonacci.\n")
                
        elif tendencia == "baixa" and forca >= 2:
            f.write("- Viés vendedor, com entradas em repiques para as resistências.\n")
            if resistencias:
                f.write(f"- Stop loss acima da resistência R1 ({resistencias[0]:.2f}).\n")
            else:
                f.write("- Definir stop loss com base na volatilidade recente do mercado.\n")
                
            if suportes:
                f.write(f"- Alvos de lucro nos suportes S1 ({suportes[0]:.2f})")
                if len(suportes) > 1:
                    f.write(f" e S2 ({suportes[1]:.2f}).\n")
                else:
                    f.write(".\n")
            else:
                f.write("- Definir alvos de lucro com base em projeções de Fibonacci.\n")
        else:
            f.write("- Mercado sem direção clara, recomenda-se cautela e operações de curto prazo.\n")
            f.write("- Aguardar confirmação de rompimento de suportes ou resistências para definir posicionamento.\n")
            f.write("- Reduzir tamanho das posições devido à indefinição técnica.\n")
        
        f.write("\n7. OBSERVAÇÕES FINAIS\n")
        f.write("- Esta análise é baseada exclusivamente em indicadores técnicos e não considera fatores fundamentais ou macroeconômicos.\n")
        f.write("- Recomenda-se complementar esta análise com informações fundamentais e de mercado antes de tomar decisões.\n")
        f.write("- Os níveis de suporte e resistência são dinâmicos e podem se alterar com novos dados de mercado.\n")
        f.write("- Análise válida para o curto prazo, devendo ser atualizada diariamente conforme evolução do mercado.\n")
    
 
(Content truncated due to size limit. Use line ranges to read in chunks)