import fs from 'fs';
import path from 'path';

// Componente para exibir o conteúdo do relatório técnico
export default function ReportContent({ content }: { content: string }) {
  // Dividir o conteúdo em seções
  const sections = content.split('\n\n');
  
  return (
    <div className="space-y-6">
      {sections.map((section, index) => {
        // Verificar se é um título de seção
        if (section.startsWith('1.') || 
            section.startsWith('2.') || 
            section.startsWith('3.') || 
            section.startsWith('4.') || 
            section.startsWith('5.') || 
            section.startsWith('6.') || 
            section.startsWith('7.')) {
          return (
            <div key={index} className="mt-8">
              <h3 className="text-xl font-semibold mb-3 text-gray-800">{section.split('\n')[0]}</h3>
              <div className="text-gray-700">
                {section.split('\n').slice(1).map((line, i) => (
                  <p key={i} className="mb-2">{line}</p>
                ))}
              </div>
            </div>
          );
        }
        
        // Conteúdo normal
        return (
          <div key={index} className="text-gray-700">
            {section.split('\n').map((line, i) => (
              <p key={i} className="mb-2">{line}</p>
            ))}
          </div>
        );
      })}
    </div>
  );
}

// Função para obter o conteúdo do relatório
export function getReportContent(asset: string) {
  try {
    const filePath = path.join(process.cwd(), 'data', `${asset}_relatorio_tecnico.txt`);
    const content = fs.readFileSync(filePath, 'utf8');
    return content;
  } catch (error) {
    console.error(`Erro ao ler o relatório de ${asset}:`, error);
    return 'Relatório técnico não disponível no momento.';
  }
}
