import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from datetime import datetime

# Diretórios para dados e resultados
dados_dir = 'dados'
resultados_dir = 'resultados'
os.makedirs(resultados_dir, exist_ok=True)

# Carregar os dados coletados
print("Carregando dados coletados...")

# Carregar dados diários
ibovespa_diario = pd.read_csv(f'{dados_dir}/ibovespa_diario.csv', index_col=0, parse_dates=True)
dolar_diario = pd.read_csv(f'{dados_dir}/dolar_diario.csv', index_col=0, parse_dates=True)

# Carregar dados de 60 minutos
ibovespa_60min = pd.read_csv(f'{dados_dir}/ibovespa_60min.csv', index_col=0, parse_dates=True)
dolar_60min = pd.read_csv(f'{dados_dir}/dolar_60min.csv', index_col=0, parse_dates=True)

# Verificar se os dados foram carregados corretamente
print("\nVerificação de dados:")
print(f"IBOVESPA Diário: {len(ibovespa_diario)} registros, período de {ibovespa_diario.index[0]} a {ibovespa_diario.index[-1]}")
print(f"Dólar Diário: {len(dolar_diario)} registros, período de {dolar_diario.index[0]} a {dolar_diario.index[-1]}")
print(f"IBOVESPA 60min: {len(ibovespa_60min)} registros, período de {ibovespa_60min.index[0]} a {ibovespa_60min.index[-1]}")
print(f"Dólar 60min: {len(dolar_60min)} registros, período de {dolar_60min.index[0]} a {dolar_60min.index[-1]}")

# Verificar valores ausentes
print("\nVerificação de valores ausentes:")
print(f"IBOVESPA Diário: {ibovespa_diario.isna().sum().sum()} valores ausentes")
print(f"Dólar Diário: {dolar_diario.isna().sum().sum()} valores ausentes")
print(f"IBOVESPA 60min: {ibovespa_60min.isna().sum().sum()} valores ausentes")
print(f"Dólar 60min: {dolar_60min.isna().sum().sum()} valores ausentes")

# Verificar colunas disponíveis
print("\nColunas disponíveis:")
print(f"IBOVESPA Diário: {ibovespa_diario.columns.tolist()}")
print(f"Dólar Diário: {dolar_diario.columns.tolist()}")

# Verificar estatísticas básicas
print("\nEstatísticas básicas para IBOVESPA Diário:")
print(ibovespa_diario['Close'].describe())

print("\nEstatísticas básicas para Dólar Diário:")
print(dolar_diario['Close'].describe())

# Verificar se há valores extremos (outliers)
def verificar_outliers(df, coluna='Close'):
    Q1 = df[coluna].quantile(0.25)
    Q3 = df[coluna].quantile(0.75)
    IQR = Q3 - Q1
    limite_inferior = Q1 - 1.5 * IQR
    limite_superior = Q3 + 1.5 * IQR
    outliers = df[(df[coluna] < limite_inferior) | (df[coluna] > limite_superior)]
    return outliers

print("\nVerificação de outliers:")
ibov_outliers = verificar_outliers(ibovespa_diario)
dolar_outliers = verificar_outliers(dolar_diario)
print(f"IBOVESPA Diário: {len(ibov_outliers)} possíveis outliers")
print(f"Dólar Diário: {len(dolar_outliers)} possíveis outliers")

# Salvar relatório de validação
with open(f'{resultados_dir}/validacao_dados.txt', 'w') as f:
    f.write("RELATÓRIO DE VALIDAÇÃO DE DADOS\n")
    f.write(f"Data de geração: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
    
    f.write("Resumo dos dados:\n")
    f.write(f"IBOVESPA Diário: {len(ibovespa_diario)} registros, período de {ibovespa_diario.index[0]} a {ibovespa_diario.index[-1]}\n")
    f.write(f"Dólar Diário: {len(dolar_diario)} registros, período de {dolar_diario.index[0]} a {dolar_diario.index[-1]}\n")
    f.write(f"IBOVESPA 60min: {len(ibovespa_60min)} registros, período de {ibovespa_60min.index[0]} a {ibovespa_60min.index[-1]}\n")
    f.write(f"Dólar 60min: {len(dolar_60min)} registros, período de {dolar_60min.index[0]} a {dolar_60min.index[-1]}\n\n")
    
    f.write("Valores ausentes:\n")
    f.write(f"IBOVESPA Diário: {ibovespa_diario.isna().sum().sum()} valores ausentes\n")
    f.write(f"Dólar Diário: {dolar_diario.isna().sum().sum()} valores ausentes\n")
    f.write(f"IBOVESPA 60min: {ibovespa_60min.isna().sum().sum()} valores ausentes\n")
    f.write(f"Dólar 60min: {dolar_60min.isna().sum().sum()} valores ausentes\n\n")
    
    f.write("Outliers detectados:\n")
    f.write(f"IBOVESPA Diário: {len(ibov_outliers)} possíveis outliers\n")
    f.write(f"Dólar Diário: {len(dolar_outliers)} possíveis outliers\n\n")
    
    f.write("Conclusão da validação:\n")
    if ibovespa_diario.isna().sum().sum() > 0 or dolar_diario.isna().sum().sum() > 0:
        f.write("ATENÇÃO: Existem valores ausentes nos dados que podem afetar a análise.\n")
    else:
        f.write("Os dados diários não apresentam valores ausentes.\n")
        
    if len(ibov_outliers) > 0 or len(dolar_outliers) > 0:
        f.write("ATENÇÃO: Foram detectados possíveis outliers que podem representar eventos extremos de mercado.\n")
    else:
        f.write("Não foram detectados outliers significativos nos dados diários.\n")

print(f"\nRelatório de validação salvo em {resultados_dir}/validacao_dados.txt")

# Preparar dados para análise técnica
print("\nPreparando dados para análise técnica...")

# Função para adicionar indicadores técnicos
def adicionar_indicadores(df):
    # Médias móveis
    df['MM8'] = df['Close'].rolling(window=8).mean()
    df['MM20'] = df['Close'].rolling(window=20).mean()
    df['MM50'] = df['Close'].rolling(window=50).mean()
    df['MM200'] = df['Close'].rolling(window=200).mean()
    
    # RSI (Relative Strength Index)
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()
    rs = avg_gain / avg_loss
    df['RSI'] = 100 - (100 / (1 + rs))
    
    # MACD (Moving Average Convergence Divergence)
    ema12 = df['Close'].ewm(span=12, adjust=False).mean()
    ema26 = df['Close'].ewm(span=26, adjust=False).mean()
    df['MACD'] = ema12 - ema26
    df['MACD_Signal'] = df['MACD'].ewm(span=9, adjust=False).mean()
    df['MACD_Hist'] = df['MACD'] - df['MACD_Signal']
    
    return df

# Adicionar indicadores aos dados diários
ibovespa_diario = adicionar_indicadores(ibovespa_diario)
dolar_diario = adicionar_indicadores(dolar_diario)

# Adicionar indicadores aos dados de 60 minutos
ibovespa_60min = adicionar_indicadores(ibovespa_60min)
dolar_60min = adicionar_indicadores(dolar_60min)

# Salvar dados processados
ibovespa_diario.to_csv(f'{resultados_dir}/ibovespa_diario_processado.csv')
dolar_diario.to_csv(f'{resultados_dir}/dolar_diario_processado.csv')
ibovespa_60min.to_csv(f'{resultados_dir}/ibovespa_60min_processado.csv')
dolar_60min.to_csv(f'{resultados_dir}/dolar_60min_processado.csv')

print("Dados validados e processados com sucesso!")
