import fs from 'fs';
import path from 'path';

// Interface para os dados de atualização
export interface UpdateInfo {
  lastUpdate: string;
  nextUpdate: string;
  version: string;
}

// Função para obter informações de atualização
export function getUpdateInfo(): UpdateInfo {
  try {
    const filePath = path.join(process.cwd(), 'data', 'update_info.json');
    
    // Verificar se o arquivo existe
    if (!fs.existsSync(filePath)) {
      // Criar arquivo com dados iniciais se não existir
      const initialData: UpdateInfo = {
        lastUpdate: new Date().toISOString(),
        nextUpdate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // Próxima atualização em 24h
        version: '1.0.0'
      };
      
      fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2));
      return initialData;
    }
    
    // Ler arquivo existente
    const content = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(content) as UpdateInfo;
  } catch (error) {
    console.error('Erro ao ler informações de atualização:', error);
    
    // Retornar dados padrão em caso de erro
    return {
      lastUpdate: new Date().toISOString(),
      nextUpdate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      version: '1.0.0'
    };
  }
}

// Função para formatar data em formato brasileiro
export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Componente para exibir informações de atualização
export default function UpdateInfo() {
  const updateInfo = getUpdateInfo();
  
  return (
    <div className="bg-blue-50 p-4 rounded-lg text-sm text-gray-700">
      <p><span className="font-medium">Última atualização:</span> {formatDate(updateInfo.lastUpdate)}</p>
      <p><span className="font-medium">Próxima atualização prevista:</span> {formatDate(updateInfo.nextUpdate)}</p>
      <p><span className="font-medium">Versão:</span> {updateInfo.version}</p>
    </div>
  );
}
