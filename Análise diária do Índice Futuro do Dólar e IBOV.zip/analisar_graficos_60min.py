import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import os
from datetime import datetime, timedelta

# Diretórios para dados e resultados
resultados_dir = 'resultados'
analise_dir = os.path.join(resultados_dir, 'analise_60min')
os.makedirs(analise_dir, exist_ok=True)

print("Iniciando análise técnica dos gráficos de 60 minutos...")

# Carregar os dados processados
ibovespa_60min = pd.read_csv(f'{resultados_dir}/ibovespa_60min_processado.csv', index_col=0, parse_dates=True)
dolar_60min = pd.read_csv(f'{resultados_dir}/dolar_60min_processado.csv', index_col=0, parse_dates=True)

# Função para identificar pontos de suporte e resistência
def identificar_suporte_resistencia(df, janela=10, threshold=0.01):
    """
    Identifica pontos de suporte e resistência baseados em máximos e mínimos locais
    """
    suportes = []
    resistencias = []
    
    # Encontrar máximos e mínimos locais
    for i in range(janela, len(df) - janela):
        # Verificar se é um máximo local
        if all(df['High'].iloc[i] > df['High'].iloc[i-j] for j in range(1, janela+1)) and \
           all(df['High'].iloc[i] > df['High'].iloc[i+j] for j in range(1, janela+1)):
            resistencias.append((df.index[i], df['High'].iloc[i]))
        
        # Verificar se é um mínimo local
        if all(df['Low'].iloc[i] < df['Low'].iloc[i-j] for j in range(1, janela+1)) and \
           all(df['Low'].iloc[i] < df['Low'].iloc[i+j] for j in range(1, janela+1)):
            suportes.append((df.index[i], df['Low'].iloc[i]))
    
    # Agrupar níveis próximos (dentro de threshold%)
    suportes_agrupados = []
    resistencias_agrupadas = []
    
    if suportes:
        suportes_ordenados = sorted(suportes, key=lambda x: x[1])
        grupo_atual = [suportes_ordenados[0]]
        
        for i in range(1, len(suportes_ordenados)):
            if abs(suportes_ordenados[i][1] - grupo_atual[0][1]) / grupo_atual[0][1] <= threshold:
                grupo_atual.append(suportes_ordenados[i])
            else:
                # Calcular o nível médio do grupo
                nivel_medio = sum(x[1] for x in grupo_atual) / len(grupo_atual)
                data_mais_recente = max(grupo_atual, key=lambda x: x[0])[0]
                suportes_agrupados.append((data_mais_recente, nivel_medio))
                grupo_atual = [suportes_ordenados[i]]
        
        # Adicionar o último grupo
        if grupo_atual:
            nivel_medio = sum(x[1] for x in grupo_atual) / len(grupo_atual)
            data_mais_recente = max(grupo_atual, key=lambda x: x[0])[0]
            suportes_agrupados.append((data_mais_recente, nivel_medio))
    
    if resistencias:
        resistencias_ordenadas = sorted(resistencias, key=lambda x: x[1])
        grupo_atual = [resistencias_ordenadas[0]]
        
        for i in range(1, len(resistencias_ordenadas)):
            if abs(resistencias_ordenadas[i][1] - grupo_atual[0][1]) / grupo_atual[0][1] <= threshold:
                grupo_atual.append(resistencias_ordenadas[i])
            else:
                # Calcular o nível médio do grupo
                nivel_medio = sum(x[1] for x in grupo_atual) / len(grupo_atual)
                data_mais_recente = max(grupo_atual, key=lambda x: x[0])[0]
                resistencias_agrupadas.append((data_mais_recente, nivel_medio))
                grupo_atual = [resistencias_ordenadas[i]]
        
        # Adicionar o último grupo
        if grupo_atual:
            nivel_medio = sum(x[1] for x in grupo_atual) / len(grupo_atual)
            data_mais_recente = max(grupo_atual, key=lambda x: x[0])[0]
            resistencias_agrupadas.append((data_mais_recente, nivel_medio))
    
    return suportes_agrupados, resistencias_agrupadas

# Função para calcular níveis de Fibonacci
def calcular_fibonacci(df, tipo='alta'):
    """
    Calcula níveis de Fibonacci para projeções e retrações
    tipo: 'alta' para movimento de alta, 'baixa' para movimento de baixa
    """
    if tipo == 'alta':
        # Para movimento de alta, encontrar o mínimo e o máximo recentes
        min_idx = df['Low'].idxmin()
        # Encontrar o máximo após o mínimo
        df_apos_min = df.loc[min_idx:]
        if len(df_apos_min) > 1:
            max_idx = df_apos_min['High'].idxmax()
            min_price = df.loc[min_idx, 'Low']
            max_price = df.loc[max_idx, 'High']
            
            # Calcular níveis de Fibonacci (retrações)
            range_price = max_price - min_price
            fib_23_6 = max_price - 0.236 * range_price
            fib_38_2 = max_price - 0.382 * range_price
            fib_50_0 = max_price - 0.5 * range_price
            fib_61_8 = max_price - 0.618 * range_price
            fib_78_6 = max_price - 0.786 * range_price
            
            # Calcular níveis de Fibonacci (extensões)
            fib_127_2 = max_price + 0.272 * range_price
            fib_161_8 = max_price + 0.618 * range_price
            fib_261_8 = max_price + 1.618 * range_price
            
            return {
                'tipo': 'alta',
                'min_idx': min_idx,
                'max_idx': max_idx,
                'min_price': min_price,
                'max_price': max_price,
                'retracao_23_6': fib_23_6,
                'retracao_38_2': fib_38_2,
                'retracao_50_0': fib_50_0,
                'retracao_61_8': fib_61_8,
                'retracao_78_6': fib_78_6,
                'extensao_127_2': fib_127_2,
                'extensao_161_8': fib_161_8,
                'extensao_261_8': fib_261_8
            }
    else:  # tipo == 'baixa'
        # Para movimento de baixa, encontrar o máximo e o mínimo recentes
        max_idx = df['High'].idxmax()
        # Encontrar o mínimo após o máximo
        df_apos_max = df.loc[max_idx:]
        if len(df_apos_max) > 1:
            min_idx = df_apos_max['Low'].idxmin()
            max_price = df.loc[max_idx, 'High']
            min_price = df.loc[min_idx, 'Low']
            
            # Calcular níveis de Fibonacci (retrações)
            range_price = max_price - min_price
            fib_23_6 = min_price + 0.236 * range_price
            fib_38_2 = min_price + 0.382 * range_price
            fib_50_0 = min_price + 0.5 * range_price
            fib_61_8 = min_price + 0.618 * range_price
            fib_78_6 = min_price + 0.786 * range_price
            
            # Calcular níveis de Fibonacci (extensões)
            fib_127_2 = min_price - 0.272 * range_price
            fib_161_8 = min_price - 0.618 * range_price
            fib_261_8 = min_price - 1.618 * range_price
            
            return {
                'tipo': 'baixa',
                'max_idx': max_idx,
                'min_idx': min_idx,
                'max_price': max_price,
                'min_price': min_price,
                'retracao_23_6': fib_23_6,
                'retracao_38_2': fib_38_2,
                'retracao_50_0': fib_50_0,
                'retracao_61_8': fib_61_8,
                'retracao_78_6': fib_78_6,
                'extensao_127_2': fib_127_2,
                'extensao_161_8': fib_161_8,
                'extensao_261_8': fib_261_8
            }
    
    return None

# Função para analisar tendência com base em médias móveis e volume
def analisar_tendencia(df):
    """
    Analisa a tendência com base nas médias móveis e volume
    """
    # Últimos 20 períodos para análise de tendência recente
    df_recente = df.iloc[-20:]
    
    # Verificar cruzamentos de médias móveis
    cruzamento_mm8_mm20 = False
    direcao_cruzamento = None
    
    if 'MM8' in df.columns and 'MM20' in df.columns:
        # Verificar se houve cruzamento nos últimos períodos
        for i in range(1, len(df_recente)):
            if df_recente['MM8'].iloc[i-1] <= df_recente['MM20'].iloc[i-1] and df_recente['MM8'].iloc[i] > df_recente['MM20'].iloc[i]:
                cruzamento_mm8_mm20 = True
                direcao_cruzamento = 'alta'
                break
            elif df_recente['MM8'].iloc[i-1] >= df_recente['MM20'].iloc[i-1] and df_recente['MM8'].iloc[i] < df_recente['MM20'].iloc[i]:
                cruzamento_mm8_mm20 = True
                direcao_cruzamento = 'baixa'
                break
    
    # Verificar posição do preço em relação às médias
    preco_acima_mm20 = df_recente['Close'].iloc[-1] > df_recente['MM20'].iloc[-1] if 'MM20' in df_recente.columns and not pd.isna(df_recente['MM20'].iloc[-1]) else None
    preco_acima_mm50 = df_recente['Close'].iloc[-1] > df_recente['MM50'].iloc[-1] if 'MM50' in df_recente.columns and not pd.isna(df_recente['MM50'].iloc[-1]) else None
    
    # Verificar inclinação das médias móveis
    inclinacao_mm20 = None
    if 'MM20' in df_recente.columns:
        mm20_inicio = df_recente['MM20'].iloc[0] if not pd.isna(df_recente['MM20'].iloc[0]) else None
        mm20_fim = df_recente['MM20'].iloc[-1] if not pd.isna(df_recente['MM20'].iloc[-1]) else None
        if mm20_inicio is not None and mm20_fim is not None:
            inclinacao_mm20 = 'alta' if mm20_fim > mm20_inicio else 'baixa'
    
    # Verificar RSI para condições de sobrecompra/sobrevenda
    condicao_rsi = None
    if 'RSI' in df_recente.columns:
        rsi_atual = df_recente['RSI'].iloc[-1]
        if not pd.isna(rsi_atual):
            if rsi_atual > 70:
                condicao_rsi = 'sobrecompra'
            elif rsi_atual < 30:
                condicao_rsi = 'sobrevenda'
            else:
                condicao_rsi = 'neutro'
    
    # Verificar MACD para sinais de tendência
    sinal_macd = None
    if 'MACD' in df_recente.columns and 'MACD_Signal' in df_recente.columns:
        # Verificar cruzamento recente
        for i in range(1, len(df_recente)):
            if df_recente['MACD'].iloc[i-1] <= df_recente['MACD_Signal'].iloc[i-1] and df_recente['MACD'].iloc[i] > df_recente['MACD_Signal'].iloc[i]:
                sinal_macd = 'compra'
                break
            elif df_recente['MACD'].iloc[i-1] >= df_recente['MACD_Signal'].iloc[i-1] and df_recente['MACD'].iloc[i] < df_recente['MACD_Signal'].iloc[i]:
                sinal_macd = 'venda'
                break
    
    # Determinar tendência geral
    tendencia = None
    forca_tendencia = 0
    
    # Critérios para tendência de alta
    if preco_acima_mm20 and preco_acima_mm50:
        tendencia = 'alta'
        forca_tendencia += 2
    elif preco_acima_mm20:
        tendencia = 'alta'
        forca_tendencia += 1
    
    # Ajustar com base em outros indicadores
    if inclinacao_mm20 == 'alta':
        if tendencia == 'alta':
            forca_tendencia += 1
        else:
            tendencia = 'alta'
            forca_tendencia = 1
    elif inclinacao_mm20 == 'baixa':
        if tendencia == 'alta':
            forca_tendencia -= 1
        else:
            tendencia = 'baixa'
            forca_tendencia = 1
    
    if cruzamento_mm8_mm20:
        if direcao_cruzamento == 'alta':
            if tendencia == 'alta':
                forca_tendencia += 1
            else:
                tendencia = 'alta'
                forca_tendencia = 1
        else:  # direcao_cruzamento == 'baixa'
            if tendencia == 'alta':
                forca_tendencia -= 1
                if forca_tendencia <= 0:
                    tendencia = 'baixa'
                    forca_tendencia = abs(forca_tendencia)
            else:
                tendencia = 'baixa'
                forca_tendencia += 1
    
    if sinal_macd == 'compra':
        if tendencia == 'alta':
            forca_tendencia += 1
        else:
            tendencia = 'alta'
            forca_tendencia = 1
    elif sinal_macd == 'venda':
        if tendencia == 'alta':
            forca_tendencia -= 1
            if forca_tendencia <= 0:
                tendencia = 'baixa'
                forca_tendencia = abs(forca_tendencia)
        else:
            tendencia = 'baixa'
            forca_tendencia += 1
    
    # Ajustar com base no RSI
    if condicao_rsi == 'sobrecompra' and tendencia == 'alta':
        forca_tendencia -= 1
    elif condicao_rsi == 'sobrevenda' and tendencia == 'baixa':
        forca_tendencia -= 1
    
    # Determinar força final da tendência
    if forca_tendencia >= 3:
        forca = 'forte'
    elif forca_tendencia >= 1:
        forca = 'moderada'
    else:
        forca = 'fraca'
    
    return {
        'tendencia': tendencia,
        'forca': forca,
        'cruzamento_mm8_mm20': cruzamento_mm8_mm20,
        'direcao_cruzamento': direcao_cruzamento,
        'preco_acima_mm20': preco_acima_mm20,
        'preco_acima_mm50': preco_acima_mm50,
        'inclinacao_mm20': inclinacao_mm20,
        'condicao_rsi': condicao_rsi,
        'sinal_macd': sinal_macd
    }

# Função para gerar gráfico com análise técnica
def gerar_grafico_analise(df, nome, suportes, resistencias, fib_alta, fib_baixa, analise_tendencia):
    """
    Gera gráfico com análise técnica completa
    """
    # Criar figura com subplots
    fig = plt.figure(figsize=(16, 12))
    
    # Grid principal para preço e médias móveis (70% da altura)
    ax1 = plt.subplot2grid((10, 1), (0, 0), rowspan=7, colspan=1)
    
    # Grid para volume (10% da altura)
    ax2 = plt.subplot2grid((10, 1), (7, 0), rowspan=1, colspan=1, sharex=ax1)
    
    # Grid para RSI (10% da altura)
    ax3 = plt.subplot2grid((10, 1), (8, 0), rowspan=1, colspan=1, sharex=ax1)
    
    # Grid para MACD (10% da altura)
    ax4 = plt.subplot2grid((10, 1), (9, 0), rowspan=1, colspan=1, sharex=ax1)
    
    # Plotar preço de fechamento
    ax1.plot(df.index, df['Close'], label='Preço de Fechamento', color='black', linewidth=1.5)
    
    # Plotar médias móveis
    if 'MM8' in df.columns:
        ax1.plot(df.index, df['MM8'], label='MM8', color='blue', linewidth=1)
    if 'MM20' in df.columns:
        ax1.plot(df.index, df['MM20'], label='MM20', color='orange', linewidth=1)
    if 'MM50' in df.columns:
        ax1.plot(df.index, df['MM50'], label='MM50', color='red', linewidth=1)
    if 'MM200' in df.columns:
        ax1.plot(df.index, df['MM200'], label='MM200', color='purple', linewidth=1.5)
    
    # Plotar suportes e resistências
    for data, nivel in suportes:
        ax1.axhline(y=nivel, color='green', linestyle='--', alpha=0.7, linewidth=1)
        ax1.text(df.index[-1], nivel, f'S: {nivel:.2f}', verticalalignment='bottom', horizontalalignment='right', color='green')
    
    for data, nivel in resistencias:
        ax1.axhline(y=nivel, color='red', linestyle='--', alpha=0.7, linewidth=1)
        ax1.text(df.index[-1], nivel, f'R: {nivel:.2f}', verticalalignment='bottom', horizontalalignment='right', color='red')
    
    # Plotar níveis de Fibonacci para movimento de alta
    if fib_alta:
        # Plotar linha do movimento principal
        ax1.plot([fib_alta['min_idx'], fib_alta['max_idx']], [fib_alta['min_price'], fib_alta['max_price']], 'g-', linewidth=2, alpha=0.7)
        
        # Plotar níveis de retração
        ax1.axhline(y=fib_alta['retracao_23_6'], color='purple', linestyle='-.', alpha=0.5, linewidth=1)
        ax1.axhline(y=fib_alta['retracao_38_2'], color='purple', linestyle='-.', alpha=0.5, linewidth=1)
        ax1.axhline(y=fib_alta['retracao_50_0'], color='purple', linestyle='-.', alpha=0.5, linewidth=1)
        ax1.axhline(y=fib_alta['retracao_61_8'], color='purple', linestyle='-.', alpha=0.5, linewidth=1)
        
        # Adicionar textos para os níveis
        ax1.text(df.index[-1], fib_alta['retracao_23_6'], f'23.6%: {fib_alta["retracao_23_6"]:.2f}', 
                 verticalalignment='bottom', horizontalalignment='right', color='purple')
        ax1.text(df.index[-1], fib_alta['retracao_38_2'], f'38.2%: {fib_alta["retracao_38_2"]:.2f}', 
                 verticalalignment='bottom', horizontalalignment='right', color='purple')
        ax1.text(df.index[-1], fib_alta['retracao_50_0'], f'50.0%: {fib_alta["retracao_50_0"]:.2f}', 
                 verticalalig
(Content truncated due to size limit. Use line ranges to read in chunks)