import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from datetime import datetime

# Diretórios para dados e resultados
resultados_dir = 'resultados'
validacao_dir = os.path.join(resultados_dir, 'validacao')
os.makedirs(validacao_dir, exist_ok=True)

print("Iniciando validação dos dados processados...")

# Função para validar os dados processados
def validar_dados(arquivo, nome_dataset):
    print(f"\nValidando {nome_dataset}...")
    
    # Carregar os dados processados
    df = pd.read_csv(f'{resultados_dir}/{arquivo}', index_col=0, parse_dates=True)
    
    # Verificar dimensões e período
    print(f"Dimensões: {df.shape}")
    print(f"Período: {df.index[0]} a {df.index[-1]}")
    
    # Verificar valores ausentes
    na_count = df.isna().sum()
    print(f"Valores ausentes por coluna:")
    print(na_count)
    
    # Verificar indicadores técnicos
    indicadores = ['MM8', 'MM20', 'MM50', 'MM200', 'RSI', 'MACD', 'MACD_Signal', 'MACD_Hist']
    for ind in indicadores:
        if ind in df.columns:
            print(f"{ind}: OK - {df[ind].count()} valores")
        else:
            print(f"{ind}: AUSENTE")
    
    # Verificar estatísticas básicas
    stats = df['Close'].describe()
    print("\nEstatísticas básicas para preços de fechamento:")
    print(stats)
    
    # Gerar gráfico de validação para preços e médias móveis
    plt.figure(figsize=(12, 6))
    plt.plot(df.index, df['Close'], label='Preço de Fechamento')
    for mm in ['MM8', 'MM20', 'MM50', 'MM200']:
        if mm in df.columns:
            plt.plot(df.index, df[mm], label=mm)
    plt.title(f'Validação de Preços e Médias Móveis - {nome_dataset}')
    plt.xlabel('Data')
    plt.ylabel('Preço')
    plt.legend()
    plt.grid(True)
    plt.savefig(f'{validacao_dir}/{arquivo.replace("_processado.csv", "_validacao_precos.png")}')
    plt.close()
    
    # Gerar gráfico de validação para RSI
    if 'RSI' in df.columns:
        plt.figure(figsize=(12, 4))
        plt.plot(df.index, df['RSI'], label='RSI')
        plt.axhline(y=70, color='r', linestyle='-', alpha=0.3)
        plt.axhline(y=30, color='g', linestyle='-', alpha=0.3)
        plt.title(f'Validação de RSI - {nome_dataset}')
        plt.xlabel('Data')
        plt.ylabel('RSI')
        plt.legend()
        plt.grid(True)
        plt.savefig(f'{validacao_dir}/{arquivo.replace("_processado.csv", "_validacao_rsi.png")}')
        plt.close()
    
    # Gerar gráfico de validação para MACD
    if 'MACD' in df.columns and 'MACD_Signal' in df.columns:
        plt.figure(figsize=(12, 4))
        plt.plot(df.index, df['MACD'], label='MACD')
        plt.plot(df.index, df['MACD_Signal'], label='Sinal MACD')
        plt.bar(df.index, df['MACD_Hist'], label='Histograma MACD', alpha=0.3)
        plt.title(f'Validação de MACD - {nome_dataset}')
        plt.xlabel('Data')
        plt.ylabel('MACD')
        plt.legend()
        plt.grid(True)
        plt.savefig(f'{validacao_dir}/{arquivo.replace("_processado.csv", "_validacao_macd.png")}')
        plt.close()
    
    # Criar relatório de validação
    with open(f'{validacao_dir}/{arquivo.replace("_processado.csv", "_relatorio_validacao.txt")}', 'w') as f:
        f.write(f"RELATÓRIO DE VALIDAÇÃO - {nome_dataset}\n")
        f.write(f"Data de geração: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        f.write("Informações gerais:\n")
        f.write(f"- Registros: {len(df)}\n")
        f.write(f"- Período: {df.index[0]} a {df.index[-1]}\n")
        f.write(f"- Colunas: {', '.join(df.columns)}\n\n")
        
        f.write("Valores ausentes:\n")
        for col, count in na_count.items():
            f.write(f"- {col}: {count} valores ausentes\n")
        f.write("\n")
        
        f.write("Indicadores técnicos:\n")
        for ind in indicadores:
            if ind in df.columns:
                na_pct = (df[ind].isna().sum() / len(df)) * 100
                f.write(f"- {ind}: {df[ind].count()} valores ({na_pct:.2f}% ausentes)\n")
            else:
                f.write(f"- {ind}: AUSENTE\n")
        f.write("\n")
        
        f.write("Estatísticas de preço de fechamento:\n")
        for stat, value in stats.items():
            f.write(f"- {stat}: {value}\n")
        f.write("\n")
        
        f.write("Conclusão da validação:\n")
        if df.isna().sum().sum() > 0:
            f.write("- ATENÇÃO: Existem valores ausentes nos dados que podem afetar a análise.\n")
        else:
            f.write("- Os dados não apresentam valores ausentes.\n")
        
        if all(ind in df.columns for ind in indicadores):
            f.write("- Todos os indicadores técnicos foram calculados corretamente.\n")
        else:
            f.write("- ATENÇÃO: Alguns indicadores técnicos estão ausentes.\n")
        
        f.write("\nGráficos de validação gerados:\n")
        f.write(f"- {arquivo.replace('_processado.csv', '_validacao_precos.png')}\n")
        f.write(f"- {arquivo.replace('_processado.csv', '_validacao_rsi.png')}\n")
        f.write(f"- {arquivo.replace('_processado.csv', '_validacao_macd.png')}\n")
    
    print(f"Relatório de validação salvo em {validacao_dir}/{arquivo.replace('_processado.csv', '_relatorio_validacao.txt')}")
    return df

# Validar cada conjunto de dados
ibovespa_diario = validar_dados('ibovespa_diario_processado.csv', 'IBOVESPA Diário')
dolar_diario = validar_dados('dolar_diario_processado.csv', 'Dólar Diário')
ibovespa_60min = validar_dados('ibovespa_60min_processado.csv', 'IBOVESPA 60min')
dolar_60min = validar_dados('dolar_60min_processado.csv', 'Dólar 60min')

print("\nValidação concluída com sucesso! Gráficos de validação disponíveis no diretório:", validacao_dir)
