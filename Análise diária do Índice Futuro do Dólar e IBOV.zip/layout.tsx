import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'Análise Técnica - Índice Futuro e Dólar Futuro',
  description: 'Análise técnica detalhada do INDFUT e WDOFUT com suportes, resistências, Fibonacci e tendências',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
