import pandas as pd
import numpy as np
import os
from datetime import datetime

# Diretórios para dados e resultados
resultados_dir = 'resultados'
os.makedirs(resultados_dir, exist_ok=True)

print("Iniciando limpeza e correção dos dados reestruturados...")

# Função para limpar e corrigir os dados
def limpar_dados(arquivo, nome_dataset):
    print(f"\nProcessando {nome_dataset}...")
    
    # Carregar os dados reestruturados
    df = pd.read_csv(f'{resultados_dir}/{arquivo}', index_col=0, parse_dates=True)
    
    # Verificar as primeiras linhas para diagnóstico
    print(f"Primeiras linhas antes da limpeza:")
    print(df.head(2))
    
    # Converter colunas para valores numéricos
    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # Renomear colunas para garantir consistência
    df.columns = ['Close', 'High', 'Low', 'Open', 'Volume']
    
    # Remover linhas com todos os valores ausentes
    df = df.dropna(how='all')
    
    # Preencher valores ausentes individuais com interpolação
    df = df.interpolate(method='linear')
    
    # Verificar resultado após limpeza
    print(f"Primeiras linhas após limpeza:")
    print(df.head(2))
    print(f"Formato dos dados: {df.shape}")
    print(f"Tipos de dados:")
    print(df.dtypes)
    
    # Salvar dados limpos
    df.to_csv(f'{resultados_dir}/{arquivo.replace("_reestruturado.csv", "_limpo.csv")}')
    
    return df

# Limpar e corrigir cada conjunto de dados
ibovespa_diario = limpar_dados('ibovespa_diario_reestruturado.csv', 'IBOVESPA Diário')
dolar_diario = limpar_dados('dolar_diario_reestruturado.csv', 'Dólar Diário')
ibovespa_60min = limpar_dados('ibovespa_60min_reestruturado.csv', 'IBOVESPA 60min')
dolar_60min = limpar_dados('dolar_60min_reestruturado.csv', 'Dólar 60min')

# Função para adicionar indicadores técnicos
def adicionar_indicadores(df):
    print(f"\nAdicionando indicadores técnicos para dataset com {len(df)} registros...")
    
    # Médias móveis
    df['MM8'] = df['Close'].rolling(window=8).mean()
    df['MM20'] = df['Close'].rolling(window=20).mean()
    df['MM50'] = df['Close'].rolling(window=50).mean()
    df['MM200'] = df['Close'].rolling(window=200).mean()
    
    # RSI (Relative Strength Index)
    delta = df['Close'].diff()
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()
    rs = avg_gain / avg_loss
    df['RSI'] = 100 - (100 / (1 + rs))
    
    # MACD (Moving Average Convergence Divergence)
    ema12 = df['Close'].ewm(span=12, adjust=False).mean()
    ema26 = df['Close'].ewm(span=26, adjust=False).mean()
    df['MACD'] = ema12 - ema26
    df['MACD_Signal'] = df['MACD'].ewm(span=9, adjust=False).mean()
    df['MACD_Hist'] = df['MACD'] - df['MACD_Signal']
    
    return df

# Adicionar indicadores aos dados limpos
print("\nAdicionando indicadores técnicos aos dados limpos...")
ibovespa_diario = adicionar_indicadores(ibovespa_diario)
dolar_diario = adicionar_indicadores(dolar_diario)
ibovespa_60min = adicionar_indicadores(ibovespa_60min)
dolar_60min = adicionar_indicadores(dolar_60min)

# Salvar dados processados com indicadores
ibovespa_diario.to_csv(f'{resultados_dir}/ibovespa_diario_processado.csv')
dolar_diario.to_csv(f'{resultados_dir}/dolar_diario_processado.csv')
ibovespa_60min.to_csv(f'{resultados_dir}/ibovespa_60min_processado.csv')
dolar_60min.to_csv(f'{resultados_dir}/dolar_60min_processado.csv')

print("\nResumo final após limpeza e processamento:")
print(f"IBOVESPA Diário: {len(ibovespa_diario)} registros, período de {ibovespa_diario.index[0]} a {ibovespa_diario.index[-1]}")
print(f"Dólar Diário: {len(dolar_diario)} registros, período de {dolar_diario.index[0]} a {dolar_diario.index[-1]}")
print(f"IBOVESPA 60min: {len(ibovespa_60min)} registros, período de {ibovespa_60min.index[0]} a {ibovespa_60min.index[-1]}")
print(f"Dólar 60min: {len(dolar_60min)} registros, período de {dolar_60min.index[0]} a {dolar_60min.index[-1]}")

print("\nDados limpos e processados com sucesso!")
