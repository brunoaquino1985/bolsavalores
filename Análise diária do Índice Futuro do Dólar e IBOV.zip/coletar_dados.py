import yfinance as yf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import mplfinance as mpf
from datetime import datetime, timedelta
import os

# Criar diretório para salvar os dados
os.makedirs('dados', exist_ok=True)
os.makedirs('imagens', exist_ok=True)

# Definir período de coleta (últimos 6 meses)
end_date = datetime.now()
start_date = end_date - timedelta(days=180)

# Símbolos para IBOVESPA Futuro e Dólar Futuro
# Nota: Como o yfinance pode não ter acesso direto aos dados de futuros brasileiros,
# vamos usar os ETFs/índices relacionados como aproximação
ibovespa_symbol = "^BVSP"  # Índice IBOVESPA
dolar_symbol = "BRL=X"     # Taxa de câmbio USD/BRL

print(f"Coletando dados de {start_date.strftime('%Y-%m-%d')} até {end_date.strftime('%Y-%m-%d')}")

# Coletar dados diários para análise de longo prazo
ibovespa_diario = yf.download(ibovespa_symbol, start=start_date, end=end_date, interval="1d")
dolar_diario = yf.download(dolar_symbol, start=start_date, end=end_date, interval="1d")

# Coletar dados de 60 minutos
ibovespa_60min = yf.download(ibovespa_symbol, start=start_date, end=end_date, interval="60m")
dolar_60min = yf.download(dolar_symbol, start=start_date, end=end_date, interval="60m")

# Coletar dados de 15 minutos (limitado aos últimos 60 dias devido a restrições do Yahoo Finance)
start_date_15min = end_date - timedelta(days=60)
ibovespa_15min = yf.download(ibovespa_symbol, start=start_date_15min, end=end_date, interval="15m")
dolar_15min = yf.download(dolar_symbol, start=start_date_15min, end=end_date, interval="15m")

# Salvar os dados coletados
ibovespa_diario.to_csv('dados/ibovespa_diario.csv')
dolar_diario.to_csv('dados/dolar_diario.csv')
ibovespa_60min.to_csv('dados/ibovespa_60min.csv')
dolar_60min.to_csv('dados/dolar_60min.csv')
ibovespa_15min.to_csv('dados/ibovespa_15min.csv')
dolar_15min.to_csv('dados/dolar_15min.csv')

print("Dados coletados e salvos com sucesso!")

# Exibir informações sobre os dados coletados
print("\nResumo dos dados coletados:")
print(f"IBOVESPA Diário: {len(ibovespa_diario)} registros")
print(f"Dólar Diário: {len(dolar_diario)} registros")
print(f"IBOVESPA 60min: {len(ibovespa_60min)} registros")
print(f"Dólar 60min: {len(dolar_60min)} registros")
print(f"IBOVESPA 15min: {len(ibovespa_15min)} registros")
print(f"Dólar 15min: {len(dolar_15min)} registros")
