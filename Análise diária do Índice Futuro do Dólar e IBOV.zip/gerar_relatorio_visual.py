import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
import os
from datetime import datetime
import shutil

# Diretórios para dados e resultados
resultados_dir = 'resultados'
relatorio_dir = os.path.join(resultados_dir, 'relatorio_final')
os.makedirs(relatorio_dir, exist_ok=True)

print("Iniciando geração do relatório visual final...")

# Função para criar relatório visual final
def gerar_relatorio_visual(ativos):
    """
    Gera um relatório visual final com todas as análises
    """
    print(f"\nGerando relatório visual final...")
    
    # Criar figura para o relatório final
    fig = plt.figure(figsize=(20, 28))
    
    # Adicionar título principal
    fig.suptitle('ANÁLISE TÉCNICA - ÍNDICE FUTURO E DÓLAR FUTURO', fontsize=24, y=0.98)
    
    # Adicionar data da análise
    plt.figtext(0.5, 0.96, f'Data da análise: {datetime.now().strftime("%d/%m/%Y")}', 
                ha='center', fontsize=14)
    
    # Criar grid para organizar as imagens
    gs = gridspec.GridSpec(len(ativos), 2, figure=fig, hspace=0.3, wspace=0.1)
    
    # Adicionar imagens para cada ativo
    for i, (ativo, nome) in enumerate(ativos):
        # Adicionar título do ativo
        plt.figtext(0.5, 0.94 - i*0.47, nome, ha='center', fontsize=18, 
                   bbox=dict(facecolor='lightgray', alpha=0.5, boxstyle='round,pad=0.5'))
        
        # Adicionar imagem da análise diária
        ax1 = fig.add_subplot(gs[i, 0])
        img_diario = plt.imread(f'{resultados_dir}/analise_diaria/{ativo}_analise_diaria.png')
        ax1.imshow(img_diario)
        ax1.axis('off')
        ax1.set_title('Análise Diária', fontsize=16, pad=20)
        
        # Adicionar imagem da análise de 60 minutos
        ax2 = fig.add_subplot(gs[i, 1])
        img_60min = plt.imread(f'{resultados_dir}/analise_60min/{ativo}_analise_60min.png')
        ax2.imshow(img_60min)
        ax2.axis('off')
        ax2.set_title('Análise 60 Minutos', fontsize=16, pad=20)
    
    # Adicionar informações de rodapé
    plt.figtext(0.5, 0.02, 'Análise gerada com base em indicadores técnicos (MM8, MM20, MM50, MM200, RSI, MACD)\n' +
                'Inclui identificação de suportes/resistências, projeções Fibonacci e análise de tendências', 
                ha='center', fontsize=12, bbox=dict(facecolor='white', alpha=0.8))
    
    # Ajustar layout
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    
    # Salvar figura
    plt.savefig(f'{relatorio_dir}/analise_tecnica_completa.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Relatório visual final salvo em {relatorio_dir}/analise_tecnica_completa.png")
    
    # Copiar todos os relatórios e imagens para o diretório final
    for ativo, _ in ativos:
        # Copiar relatórios técnicos
        shutil.copy(f'{resultados_dir}/analise_consolidada/{ativo}_relatorio_tecnico.txt', 
                    f'{relatorio_dir}/{ativo}_relatorio_tecnico.txt')
        
        # Copiar imagens individuais
        shutil.copy(f'{resultados_dir}/analise_diaria/{ativo}_analise_diaria.png', 
                    f'{relatorio_dir}/{ativo}_analise_diaria.png')
        shutil.copy(f'{resultados_dir}/analise_60min/{ativo}_analise_60min.png', 
                    f'{relatorio_dir}/{ativo}_analise_60min.png')
        shutil.copy(f'{resultados_dir}/analise_consolidada/{ativo}_analise_consolidada.png', 
                    f'{relatorio_dir}/{ativo}_analise_consolidada.png')
    
    # Criar arquivo README com instruções
    with open(f'{relatorio_dir}/README.txt', 'w') as f:
        f.write("ANÁLISE TÉCNICA - ÍNDICE FUTURO E DÓLAR FUTURO\n")
        f.write(f"Data de geração: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
        
        f.write("CONTEÚDO DO RELATÓRIO:\n\n")
        
        f.write("1. VISÃO GERAL\n")
        f.write("   - analise_tecnica_completa.png: Relatório visual completo com todas as análises\n\n")
        
        f.write("2. ANÁLISES INDIVIDUAIS\n")
        for ativo, nome in ativos:
            f.write(f"   {nome}:\n")
            f.write(f"   - {ativo}_analise_diaria.png: Análise técnica do gráfico diário\n")
            f.write(f"   - {ativo}_analise_60min.png: Análise técnica do gráfico de 60 minutos\n")
            f.write(f"   - {ativo}_analise_consolidada.png: Análise consolidada dos dois timeframes\n")
            f.write(f"   - {ativo}_relatorio_tecnico.txt: Relatório técnico detalhado\n\n")
        
        f.write("3. COMO UTILIZAR ESTE RELATÓRIO\n")
        f.write("   - As imagens contêm análises técnicas completas com suportes, resistências, Fibonacci e tendências\n")
        f.write("   - Os relatórios técnicos fornecem detalhes adicionais e recomendações\n")
        f.write("   - Recomenda-se analisar tanto o timeframe diário quanto o de 60 minutos para decisões\n")
        f.write("   - Esta análise deve ser atualizada diariamente para acompanhar a evolução do mercado\n\n")
        
        f.write("4. INDICADORES UTILIZADOS\n")
        f.write("   - Médias Móveis: MM8, MM20, MM50, MM200\n")
        f.write("   - Osciladores: RSI (Índice de Força Relativa), MACD\n")
        f.write("   - Suportes e Resistências: Identificados por máximos e mínimos locais\n")
        f.write("   - Fibonacci: Retrações e projeções calculadas a partir de pivôs significativos\n\n")
        
        f.write("5. OBSERVAÇÕES IMPORTANTES\n")
        f.write("   - Esta análise é baseada exclusivamente em indicadores técnicos\n")
        f.write("   - Recomenda-se complementar com análise fundamentalista e de sentimento de mercado\n")
        f.write("   - Passado não é garantia de resultados futuros\n")
        f.write("   - Utilize esta análise como uma ferramenta de apoio à decisão, não como recomendação definitiva\n")
    
    print(f"Arquivo README salvo em {relatorio_dir}/README.txt")

# Lista de ativos para o relatório
ativos = [
    ('IBOVESPA', 'Índice Bovespa Futuro (INDFUT)'),
    ('DOLAR', 'Dólar Futuro (WDOFUT)')
]

# Gerar relatório visual final
gerar_relatorio_visual(ativos)

print("\nRelatório visual final concluído com sucesso!")
